//
//  LiveEventViewController.h
//  RecentLiveEvents
//
//  Created by Yahya  on 9/24/17.
//  Copyright © 2017 Towson University. All rights reserved.
//

#import <UIKit/UIKit.h>
#import <MediaPlayer/MediaPlayer.h>
@import AVFoundation;
@import AVKit;
#import "liveVideoViewCell.h"



@interface LiveEventViewController : UIViewController <UITableViewDataSource, UITableViewDelegate, NSURLConnectionDataDelegate>


@property (strong, nonatomic) IBOutlet UITableView *tableView2;

@property(nonatomic, strong)NSMutableArray *liveVideoArray;
@property(nonatomic, strong)NSMutableArray *videoContent;

//@property(nonatomic, strong)NSArray *reverseOrder;

- (IBAction)playLiveVideos:(id)sender;




@end
