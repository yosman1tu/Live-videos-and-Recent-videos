//
//  VideoViewCell.h
//  RecentLiveEvents
//
//  Created by Yahya  on 9/24/17.
//  Copyright © 2017 Towson University. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "RecentLiveItems.h"


@interface VideoViewCell : UITableViewCell

@property (strong, nonatomic) IBOutlet UIImageView *imageView1;

@property (strong, nonatomic) IBOutlet UILabel *title;
@property (strong, nonatomic) IBOutlet UILabel *myDescription;
@property (strong, nonatomic) IBOutlet UILabel *myDate;
@property (strong, nonatomic) IBOutlet UILabel *IDs;

@property (strong, nonatomic) IBOutlet UIButton *playLiveButton;



-(void)setDetails:(RecentLiveItems *) new;


@end
