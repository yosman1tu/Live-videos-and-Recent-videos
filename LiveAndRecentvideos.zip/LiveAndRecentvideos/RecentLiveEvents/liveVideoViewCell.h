//
//  liveVideoViewCell.h
//  RecentLiveEvents
//
//  Created by Yahya  on 9/24/17.
//  Copyright © 2017 Towson University. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "RecentLiveItems.h"


@interface liveVideoViewCell : UITableViewCell

@property (strong, nonatomic) IBOutlet UIImageView *imageView1;

@property (strong, nonatomic) IBOutlet UILabel *title;


@property (strong, nonatomic) IBOutlet UILabel *startT;

@property (strong, nonatomic) IBOutlet UILabel *endT;

@property (strong, nonatomic) IBOutlet UILabel *nowTime;
@property (strong, nonatomic) IBOutlet UILabel *descriptions;

@property (strong, nonatomic) IBOutlet UIButton *playImage;
@property (strong, nonatomic) IBOutlet UILabel *remianingTimeLive;

-(void)setDetails:(RecentLiveItems *) new;



@end
