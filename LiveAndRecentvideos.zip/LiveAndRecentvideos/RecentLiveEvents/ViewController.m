//
//  ViewController.m
//  RecentLiveEvents
//
//  Created by Yahya  on 9/24/17.
//  Copyright © 2017 Towson University. All rights reserved.
//

#import "ViewController.h"

@interface ViewController ()
{
    NSMutableData *webData;
    NSURLConnection *connection;
    NSMutableArray *array;
}
@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view, typically from a nib.
    [[self myTableView]setDelegate:self];
    [[self myTableView]setDataSource:self];
    array = [[NSMutableArray alloc]init];
    
    NSURL *url = [NSURL URLWithString:@"http://itunes.apple.com/us/rss/topmovies/limit=10/genre=4401/json"];
    
    
    
    
    //NSURL *url= @"http://api.dvidshub.net/search?api_key=key-53ce7dc88f935&branch=Marines&page=1&max_results=50&thumb_width=600&type=video&tags_exclude=extra&sort=date&category[]=Newscasts&category[]=Package&category[]=Commercials";
    
    
    
    
    
    
    //http://api.dvidshub.net/search?api_key=key-53ce7dc88f935&branch=Marines&page=1&max_results=50&thumb_width=600&type=video&tags_exclude=extra&sort=date&category
    
    //NSURL *url = [NSURL URLWithString:@"http://api.dvidshub.net/search?api_key=key-53ce7dc88f935&branch=Marines&page=1&max_results=50&thumb_width=600&type=video&tags_exclude=extra&sort=date&category"];
    
    
    
    
    //NSURL *url = [NSURL URLWithString:@"https://newsapi.org/v1/articles?source=techcrunch&sortBy=top&apiKey=64872d87c2ca48f08e3d576a77a3"];
    
    
    
    //NSURL *url = [NSURL URLWithString:@"http://itunes.apple.com/us/rss/topalbums/limit=10/json"];
    //    NSURL *url = [NSURL URLWithString:@"http://api.themoviedb.org/3/genre/list?api_key=65b56d5d3fa43ad24d10b2786b3d0b96"];  //3
    //NSURL *url = [NSURL URLWithString:@"http://www.physics.leidenuniv.nl/json/news.php"];//2
    
    //NSURL *url = [NSURL URLWithString:@"http://itunes.apple.com/us/rss/topaudiobooks/limit=22/json"];//1
    
    
    NSURLRequest *request = [NSURLRequest requestWithURL:url];
    
    connection = [NSURLConnection connectionWithRequest:request delegate:self];
    
    if(connection)
    {
        webData = [[NSMutableData alloc] init];
    }
    
}


- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

-(void)connection:(NSURLConnection *)connection didReceiveResponse:(NSURLResponse *)response
{
    [webData setLength: 0];
}

-(void)connection:(NSURLConnection *)connection didReceiveData:(NSData *)data
{
    
    [webData appendData:data];
}

-(void)connection:(NSURLConnection *)connection didFailWithError:(NSError *)error
{
    NSLog(@"fail with error");
}

-(void)connectionDidFinishLoading:(NSURLConnection *)connection
{
    NSDictionary *allDataDictionary = [NSJSONSerialization JSONObjectWithData:webData options:0 error:nil];
    NSDictionary *feed =  [allDataDictionary objectForKey:@"feed"];
    NSArray *arrayOfEntry = [feed objectForKey:@"entry"];
    
    for(NSDictionary *diction in arrayOfEntry){
        NSDictionary *title = [diction objectForKey:@"title"];
        NSString *label = [title objectForKey:@"label"];
        [array addObject:label];
        
        
        
        //        NSDictionary *allDataDictionary = [NSJSONSerialization JSONObjectWithData:webData options:0 error:nil];
        //        NSDictionary *page_info =  [allDataDictionary objectForKey:@"page_info"];
        //        NSArray *arrayOfEntry = [page_info objectForKey:@"results"];
        //
        //        for(NSDictionary *diction in arrayOfEntry){
        //            //NSDictionary *title = [diction objectForKey:@"title"];
        //
        //            NSString *title = [diction objectForKey:@"title"];
        //            [array addObject:title];
        
        
        //    NSDictionary *allDataDictionary = [NSJSONSerialization JSONObjectWithData:webData options:0 error:nil];
        //    NSArray *arrayOfNewsItems = [allDataDictionary objectForKey:@"newsItems"];
        //
        //    for(NSDictionary *diction in arrayOfNewsItems){
        //        NSDictionary *title = [diction objectForKey:@"title"];  //2
        //        //NSString *label = [title objectForKey:@"label"];
        //
        //        //[array addObject:label];
        //        [array addObject:title];
        
        
        //    NSDictionary *allDataDictionary = [NSJSONSerialization JSONObjectWithData:webData options:0 error:nil];
        //        //NSDictionary *Gen =  [allDataDictionary objectForKey:@"genres"];
        //        NSArray *arrayOfResults = [allDataDictionary objectForKey:@"genres"];
        //
        //        for(NSDictionary *diction in arrayOfResults){
        //            //NSDictionary *title = [diction objectForKey:@"title"];   //3
        //            NSString *name = [diction objectForKey:@"name"];
        //
        //             [array addObject:name];
        
        
        //    NSDictionary *allDataDictionary = [NSJSONSerialization JSONObjectWithData:webData options:0 error:nil];
        //    NSDictionary *page_info =  [allDataDictionary objectForKey:@"page_info"];
        //    NSArray *arrayOfResults = [page_info objectForKey:@"results"];
        //
        //    for(NSDictionary *diction in arrayOfResults){
        //        //NSDictionary *title = [diction objectForKey:@"title"];
        //        NSString *title = [diction objectForKey:@"title"];
        //
        //        [array addObject:title];
        //
        
    }
    [[self myTableView]reloadData];
}
//- (IBAction)getTop10Button:(id)sender {
//
//    [array removeAllObjects];
//
//    NSURL *url = [NSURL URLWithString:@"http://itunes.apple.com/us/rss/topmovies/limit=10/genre=4401/json"];
//
//
//
//
//    //NSURL *url= @"http://api.dvidshub.net/search?api_key=key-53ce7dc88f935&branch=Marines&page=1&max_results=50&thumb_width=600&type=video&tags_exclude=extra&sort=date&category[]=Newscasts&category[]=Package&category[]=Commercials";
//
//
//
//
//
//
//    //http://api.dvidshub.net/search?api_key=key-53ce7dc88f935&branch=Marines&page=1&max_results=50&thumb_width=600&type=video&tags_exclude=extra&sort=date&category
//
//    //NSURL *url = [NSURL URLWithString:@"http://api.dvidshub.net/search?api_key=key-53ce7dc88f935&branch=Marines&page=1&max_results=50&thumb_width=600&type=video&tags_exclude=extra&sort=date&category"];
//
//
//
//
//    //NSURL *url = [NSURL URLWithString:@"https://newsapi.org/v1/articles?source=techcrunch&sortBy=top&apiKey=64872d87c2ca48f08e3d576a77a3"];
//
//
//
//    //NSURL *url = [NSURL URLWithString:@"http://itunes.apple.com/us/rss/topalbums/limit=10/json"];
//    //    NSURL *url = [NSURL URLWithString:@"http://api.themoviedb.org/3/genre/list?api_key=65b56d5d3fa43ad24d10b2786b3d0b96"];  //3
//    //NSURL *url = [NSURL URLWithString:@"http://www.physics.leidenuniv.nl/json/news.php"];//2
//
//    //NSURL *url = [NSURL URLWithString:@"http://itunes.apple.com/us/rss/topaudiobooks/limit=22/json"];//1
//
//
//    NSURLRequest *request = [NSURLRequest requestWithURL:url];
//
//    connection = [NSURLConnection connectionWithRequest:request delegate:self];
//
//    if(connection)
//    {
//        webData = [[NSMutableData alloc] init];
//    }
//}

-(NSInteger)numberOfSectionsInTableView:(UITableView *)tableView
{
    return 1;
}

-(NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    
    return [array count];
}

-(UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    static NSString *CellIdentifier = @"Cell";
    UITableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:CellIdentifier];
    
    if(!cell)
    {
        cell = [[UITableViewCell alloc]initWithStyle:UITableViewCellStyleDefault reuseIdentifier:CellIdentifier];
    }
    cell.textLabel.text = [array objectAtIndex:indexPath.row];
    return cell;
}
@end

