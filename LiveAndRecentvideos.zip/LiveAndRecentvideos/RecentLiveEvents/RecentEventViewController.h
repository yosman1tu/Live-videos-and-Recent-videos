//
//  RecentEventViewController.h
//  RecentLiveEvents
//
//  Created by Yahya  on 9/24/17.
//  Copyright © 2017 Towson University. All rights reserved.
//

#import <UIKit/UIKit.h>
#import <MediaPlayer/MediaPlayer.h>
@import AVFoundation;
@import AVKit;

@interface RecentEventViewController : UIViewController<UITableViewDataSource, UITableViewDelegate, NSURLConnectionDataDelegate>

@property(nonatomic, strong)NSMutableArray *videoArray;
@property(nonatomic, strong)NSMutableArray *videoContent;

@property (strong, nonatomic) IBOutlet UITableView *tableView1;

@property (strong, nonatomic) IBOutlet UISegmentedControl *segment;
- (IBAction)showEventType:(id)sender;

- (IBAction)UpcomingEvents:(id)sender;
- (IBAction)playVideo:(id)sender;


@end

//  RecentEventViewController.h
//  RecentLiveEvents
//
//  Created by Yahya  on 9/24/17.
//  Copyright © 2017 Towson University. All rights reserved.
//

//#import <UIKit/UIKit.h>
//#import <MediaPlayer/MediaPlayer.h>
//@import AVFoundation;
//@import AVKit;
//
//
//
//@interface RecentEventViewController : UIViewController<UITableViewDataSource, UITableViewDelegate, NSURLConnectionDataDelegate>
//@property (strong, nonatomic) IBOutlet UITableView *myTableView;
//
//@property(nonatomic, strong)NSMutableArray *array;
//
//- (IBAction)getTop10Button:(id)sender;

//
//@end

