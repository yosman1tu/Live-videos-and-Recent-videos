//
//  RecentLiveItems.m
//  RecentLiveEvents
//
//  Created by Yahya  on 9/24/17.
//  Copyright © 2017 Towson University. All rights reserved.
//

#import "RecentLiveItems.h"

@implementation RecentLiveItems

-(void)loadData
{
    NSURL *url = [NSURL URLWithString:self.Thumbnail];
    //NSURL *Vurl = [NSURL URLWithString:self.SrcMp4];
    //NSData *imageData = [[NSData alloc] initWithContentsOfURL:urlL];
    
    
    
    self.imageData = [NSData dataWithContentsOfURL:url];
    //self.imageData = [NSData dataWithContentsOfURL:Vurl];
    
    _nowTime = [NSDate date];
    NSDateFormatter *outputFormatter = [[NSDateFormatter alloc] init];
    [outputFormatter setDateFormat:@"HH:mm:ss"];
    NSString *newDateString = [outputFormatter stringFromDate:_nowTime];
    NSLog(@"newDateString %@", newDateString);
    //[outputFormatter release];
    
}

@end
