//
//  LiveEventViewController.m
//  RecentLiveEvents
//
//  Created by Yahya  on 9/24/17.
//  Copyright © 2017 Towson University. All rights reserved.
//

#import "LiveEventViewController.h"
#import "liveVideoViewCell.h"
#import "RecentLiveItems.h"

@interface LiveEventViewController ()
{
    NSMutableData *firstWebData;
    NSURLConnection *firstConnection;
    
    NSMutableData *secondWebData;
    NSURLConnection *secondConnection;
    
    NSTimer *eventTimer;

    
    BOOL isRecent;
    
    
    
    MPMoviePlayerViewController *player;
    
}

@end

@implementation LiveEventViewController

@synthesize tableView2,liveVideoArray,videoContent;

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view.
    
    
    self.title = @"Live Events";
    
    liveVideoArray = [[NSMutableArray alloc]init];
    
    //reverseOrder = [[NSMutableArray alloc]init];
    
    videoContent = [[NSMutableArray alloc]init];
    
    //reverseOrder = liveVideoArray;
    
    
    NSURL *url = [NSURL URLWithString:[NSString stringWithFormat:@"https://api.dvidshub.net/live/list?api_key=key-53ce7dc88f935&thumb_width=900&max_results=50&sortdir=desc"]];
    
    //NSURL *url = [NSURL URLWithString:[NSString stringWithFormat:@" https://api.dvidshub.net/live/list?max_results=30&api_key=key-53ce7dc88f935&thumb_width=90"]];
    
    
    
    
    NSURLRequest *request = [NSURLRequest requestWithURL:url];
    
    // NSLog(@"My Header Value: %@",request);
    
    firstConnection = [NSURLConnection connectionWithRequest:request delegate:self];
    
    if(firstConnection)
    {
        firstWebData = [[NSMutableData alloc] init];
    }
    

    [self updateTimer];
    
    self.navigationController.navigationBar.topItem.title = @"Back";

    
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

//methods to perform the connection and population of data

-(void)connection: (NSURLConnection *)connection didReceiveResponse:(NSURLResponse *)response
{
    if(connection==firstConnection){
        firstWebData = [[NSMutableData alloc]init];
    }
    else if(connection==secondConnection){
        secondWebData = [[NSMutableData alloc]init];
    }
}

-(void)connection:(NSURLConnection *)connection didReceiveData:(NSData *)thedata
{
    if(connection==firstConnection){
        [firstWebData appendData:thedata];
    }
    else if(connection==secondConnection){
        [secondWebData appendData:thedata];
    }
}

-(void)connection:(NSURLConnection *)connection didFailWithError:(NSError *)error
{
    NSLog(@"fail with error");
}

-(void)connectionDidFinishLoading:(NSURLConnection *)connection
{
    
    if(connection==firstConnection) {
        
        
        NSDictionary *allDataDictionary = [NSJSONSerialization JSONObjectWithData:firstWebData options:0 error:nil];
        //NSDictionary *Gen =  [allDataDictionary objectForKey:@"genres"];
        NSArray *arrayOfResults = [allDataDictionary objectForKey:@"results"];
        //NSMutableArray *Array = [allDataDictionary objectForKey:@"results"];
        
        NSSortDescriptor *descriptor = [[NSSortDescriptor alloc] initWithKey:@"begin" ascending:YES];
        NSArray *descriptors = [NSMutableArray arrayWithObject: descriptor];
        NSArray *reArrangeByDate = [arrayOfResults sortedArrayUsingDescriptors:descriptors];
        
        NSLog(@"Sort Result: %@", reArrangeByDate);
        
        
        for(NSDictionary *diction in reArrangeByDate){
            
            RecentLiveItems *allObjects = [[RecentLiveItems alloc]init];
            
            allObjects.myTitle = [diction objectForKey:@"title"];
            
            allObjects.startTime = [diction objectForKey:@"begin"];
            
            allObjects.endTime = [diction objectForKey:@"end"];
            
            allObjects.Describe = [diction objectForKey:@"description"];
            
            
            
            NSString *ids =  [diction objectForKey:@"id"];
            
            
            NSLog(@"The LIVEeventID is: %@", ids);
            NSLog(@"Log me");
            
            NSDictionary *Thumbnails = [diction objectForKey:@"thumbnail"];
            NSString *imageUrl = [Thumbnails objectForKey:@"url"];
            
            
            allObjects.Thumbnail=imageUrl;
            
            [liveVideoArray addObject:allObjects];
            [videoContent addObject:ids];
            
            
            
        }
        [[self tableView2]reloadData];
        
    }
}

//else if(connection == secondConnection){
//
//
//        NSDictionary *allDataDictionary = [NSJSONSerialization JSONObjectWithData:secondWebData options:0 error:nil];
//        NSDictionary *results =  [allDataDictionary objectForKey:@"results"];
//
//
//        NSArray *arrayOfFiles = [results objectForKey:@"thumbnail"];
//
//
//
//        if (arrayOfFiles != nil)
//
//        {
//
//            NSDictionary *diction = [arrayOfFiles objectAtIndex:0];
//            NSString *srcMp4 = [diction objectForKey:@"url"];
//
//
//            NSLog(@"This is my url %@", srcMp4);
//            NSURL *second_connection_url = [NSURL URLWithString:srcMp4];
//
//            player = [[MPMoviePlayerViewController alloc] initWithContentURL:second_connection_url];
//            [self presentMoviePlayerViewControllerAnimated:player];
//
//
//        }
//
//
//    }
//
//    [[self tableView2]reloadData];
//
//
//
//}


-(NSInteger)numberOfSectionsInTableView:(UITableView *)tableView
{
    return 1;
}

-(NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    
    return [liveVideoArray count];
}

-(UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    static NSString *CellIdentifier = @"Cell";
    liveVideoViewCell *cell = [tableView2 dequeueReusableCellWithIdentifier:CellIdentifier];
    
   
    cell.playImage.tag = indexPath.row;
    [cell.playImage addTarget:self action:@selector(playLiveVideos:) forControlEvents:UIControlEventTouchUpInside];
    
    
    if(!cell)
    {
        cell = [[liveVideoViewCell alloc]initWithStyle:UITableViewCellStyleDefault reuseIdentifier:CellIdentifier];
    }
    //cell.textLabel.text = [liveVideoArray objectAtIndex:indexPath.row];
    
    
    
    RecentLiveItems *objectLiveVideo = [liveVideoArray objectAtIndex:indexPath.row];
    
    
    NSString *beginDate = objectLiveVideo.startTime;
    
    //objectLiveVideo.startTime = [self formatteDate:objectLiveVideo.startTime];
    
    NSDateFormatter *dateFormatter = [[NSDateFormatter alloc] init];
    [dateFormatter setDateFormat:@"yyyy-MM-dd'T'HH:mm:ssZ"]; // 2016-10-04T16:25:00+00:00
    NSDate *ts_utc = [dateFormatter dateFromString:beginDate];
    
    
    NSTimeZone *currentTimeZone = [NSTimeZone localTimeZone];
    NSDateFormatter* df_local = [[NSDateFormatter alloc] init];
    [df_local setTimeZone:currentTimeZone];
    [df_local setDateFormat:@"yyyy.MM.dd G 'at' HH:mm:ss zzz"];
    
    
    
    NSDate* currentDate = [NSDate date];
    NSDate* startDate = ts_utc;
    NSTimeInterval distanceBetweenDates = [startDate timeIntervalSinceDate:currentDate];
    int seconds = (int)distanceBetweenDates % 60;
    int minutes = (int)(distanceBetweenDates / 60) % 60;
    int hours = distanceBetweenDates / 3600;
    
    
    
    if (seconds<0){
        cell.playImage.hidden=false;
        // return @"";
    }else {
        cell.playImage.hidden=true;
        //return [NSString stringWithFormat:@"%2d hrs:%02d min:%02d sec",hours ,minutes, seconds];
    }
    
  
    
    [cell setDetails:objectLiveVideo];
    
    
    return cell;
}

//- (void)reloadRowsAtIndexPaths:(NSArray *)indexPaths withRowAnimation:(UITableViewRowAnimation)animation;
//{
//    eventTimer = [NSTimer scheduledTimerWithTimeInterval:1.0 target:self selector:@selector(timerElapsed) userInfo:nil repeats:YES];
//
//
//}


-(void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath
{
    
    RecentLiveItems *objectLiveVideo = [liveVideoArray objectAtIndex:indexPath.row];
    
    
    NSString *beginDate = objectLiveVideo.startTime;
    
    NSDateFormatter *dateFormatter = [[NSDateFormatter alloc] init];
    [dateFormatter setDateFormat:@"yyyy-MM-dd'T'HH:mm:ssZ"]; // 2016-10-04T16:25:00+00:00
    NSDate *ts_utc = [dateFormatter dateFromString:beginDate];
    
    NSTimeZone *currentTimeZone = [NSTimeZone localTimeZone];
    NSDateFormatter* df_local = [[NSDateFormatter alloc] init];
    [df_local setTimeZone:currentTimeZone];
    [df_local setDateFormat:@"yyyy.MM.dd G 'at' HH:mm:ss zzz"];
    
    
    
    NSDate* currentDate = [NSDate date];
    NSDate* startDate = ts_utc;
    NSTimeInterval distanceBetweenDates = [startDate timeIntervalSinceDate:currentDate];
    int seconds = (int)distanceBetweenDates % 60;
    int minutes = (int)(distanceBetweenDates / 60) % 60;
    int hours = distanceBetweenDates / 3600;
    
    
    
    
    if (seconds<0){
        
        
        NSString *CurrentID=[videoContent objectAtIndex:indexPath.row];
        NSURL *connection_url = [NSURL URLWithString:CurrentID];
        
        
        connection_url = [NSURL URLWithString:[NSString stringWithFormat:@"http://api.dvidshub.net/hls/live/%@.m3u8?api_key=key-53ce7dc88f935",CurrentID]];
        
        NSLog(@"The id is: %@", CurrentID);
        NSLog(@"The url is: %@", connection_url);
        
        
        AVPlayer *player1 = [AVPlayer playerWithURL:connection_url];
        
        // create a player view controller
        AVPlayerViewController *controller = [[AVPlayerViewController alloc]init];
        controller.player = player1;
        
        
        [self presentViewController:controller animated:YES completion:nil];
        [player1 play];
        
        
        
        NSLog(@"it is time: " );
        
        
    }else {
        
        NSLog(@"Not time yet: " );
    }
    
    
}

-(void)updateTimer{
eventTimer = [NSTimer scheduledTimerWithTimeInterval:1.0 target:self selector:@selector(timerElapsed) userInfo:nil repeats:YES];
}

//- (void)viewWillAppear:(BOOL)animated{
//
//    eventTimer = [NSTimer scheduledTimerWithTimeInterval:1.0 target:self selector:@selector(timerElapsed) userInfo:nil repeats:YES];
//
//}

-(void)timerElapsed{
//
    

    for (int j=0; j<liveVideoArray.count; j++) {
        for (int i=0; i<liveVideoArray.count; i++) {
            NSIndexPath *indexPath = [NSIndexPath indexPathForRow:i inSection:j];
            //Do something with your indexPath. Maybe you want to get your cell,
            // like this:
            liveVideoViewCell *cell = [tableView2 cellForRowAtIndexPath:indexPath];
        
            ///******************************************///
            
            RecentLiveItems *objectLiveVideo = [liveVideoArray objectAtIndex:indexPath.row];
            
            
            NSString *beginDate = objectLiveVideo.startTime;
            
            NSDateFormatter *dateFormatter = [[NSDateFormatter alloc] init];
            [dateFormatter setDateFormat:@"yyyy-MM-dd'T'HH:mm:ssZ"]; // 2016-10-04T16:25:00+00:00
            NSDate *ts_utc = [dateFormatter dateFromString:beginDate];
            
            NSTimeZone *currentTimeZone = [NSTimeZone localTimeZone];
            NSDateFormatter* df_local = [[NSDateFormatter alloc] init];
            [df_local setTimeZone:currentTimeZone];
            [df_local setDateFormat:@"yyyy.MM.dd G 'at' HH:mm:ss zzz"];
            
            
            
            NSDate* currentDate = [NSDate date];
            NSDate* startDate = ts_utc;
            NSTimeInterval distanceBetweenDates = [startDate timeIntervalSinceDate:currentDate];
            int seconds = (int)distanceBetweenDates % 60;
            int minutes = (int)(distanceBetweenDates / 60) % 60;
            int hours = distanceBetweenDates / 3600;
            
            
            ///******************************************///
            
            //cell.textLabel.text =  [NSString stringWithFormat:@"%2d hrs:%02d min:%02d sec",hours ,minutes, seconds];
            
            
            if (seconds<0){
                
                //remianingTimeLive.hidden=true;
                cell.remianingTimeLive.text = [NSString stringWithFormat:@"Live now"];
                
            }else {
          
            cell.remianingTimeLive.text =  [NSString stringWithFormat:@"%2d hrs:%02d min:%02d sec",hours ,minutes, seconds];
            

        }
    }
    }


}



// This Methode is used to return
- (NSString*)formatteDate:(NSString*)date{
    NSDateFormatter *dateFormatter = [[NSDateFormatter alloc] init];
    [dateFormatter setDateFormat:@"yyyy-MM-dd'T'HH:mm:ssZ"]; // 2016-10-04T16:25:00+00:00
    NSDate *ts_utc = [dateFormatter dateFromString:date];
    NSDateFormatter* df_utc = [[NSDateFormatter alloc] init];
    [df_utc setTimeZone:[NSTimeZone timeZoneWithName:@"UTC"]];
    [df_utc setDateFormat:@"yyyy.MM.dd G 'at' HH:mm:ss zzz"];
    
    NSTimeZone *currentTimeZone = [NSTimeZone localTimeZone];
    NSDateFormatter* df_local = [[NSDateFormatter alloc] init];
    [df_local setTimeZone:currentTimeZone];
    [df_local setDateFormat:@"yyyy.MM.dd  'at' hh:mm:ss a"];
    
    //NSString* ts_utc_string = [df_utc stringFromDate:ts_utc];
    NSString* ts_local_string = [df_local stringFromDate:ts_utc];
    return  ts_local_string;
}

- (NSString *)timeFormatted:(NSString*)beginDate cell:(liveVideoViewCell*)cell {
    
    NSDateFormatter *dateFormatter = [[NSDateFormatter alloc] init];
    [dateFormatter setDateFormat:@"yyyy-MM-dd'T'HH:mm:ssZ"]; // 2016-10-04T16:25:00+00:00
    NSDate *ts_utc = [dateFormatter dateFromString:beginDate];
    
    NSTimeZone *currentTimeZone = [NSTimeZone localTimeZone];
    NSDateFormatter* df_local = [[NSDateFormatter alloc] init];
    [df_local setTimeZone:currentTimeZone];
    [df_local setDateFormat:@"yyyy.MM.dd G 'at' HH:mm:ss zzz"];
    
    NSDate* currentDate = [NSDate date];
    NSDate* startDate = ts_utc;
    NSTimeInterval distanceBetweenDates = [startDate timeIntervalSinceDate:currentDate];
    int seconds = (int)distanceBetweenDates % 60;
    int minutes = (int)(distanceBetweenDates / 60) % 60;
    int hours = distanceBetweenDates / 3600;
    if (seconds<0){
        cell.playImage.hidden=false;
        

        return @"";
    }else {
        cell.playImage.hidden=true;
        //cell.remianingTimeLive.hidden=true;
        return [NSString stringWithFormat:@"%2d hrs:%02d min:%02d sec",hours ,minutes, seconds];
    }
}


//This for live or upcoming videos
//https://api.dvidshub.net/live/list?api_key=key-53ce7dc88f935&thumb_width=900&max_results=50&sortdi

//Recent videos
//https://api.dvidshub.net/live/list?api_key=key-53ce7dc88f935&thumb_width=900&to_date=2017-09-11T18:24:33-04:00&max_results=50&sortdir=desc&hashtag=USMC

- (IBAction)playLiveVideos:(id)sender {
    
    
    
    UIButton *senderButton = (UIButton *)sender;
    
    NSLog(@"Current row is: =%ld", (long)senderButton.tag);
    
    
    
    // USAJobObject *NewObject = [jsonTitle objectAtIndex:senderButton.tag];
    
    
    RecentLiveItems *objectLiveVideo = [liveVideoArray objectAtIndex:senderButton.tag];
    
    NSString *beginDate = objectLiveVideo.startTime;
    
    NSDateFormatter *dateFormatter = [[NSDateFormatter alloc] init];
    [dateFormatter setDateFormat:@"yyyy-MM-dd'T'HH:mm:ssZ"]; // 2016-10-04T16:25:00+00:00
    NSDate *ts_utc = [dateFormatter dateFromString:beginDate];
    
    NSTimeZone *currentTimeZone = [NSTimeZone localTimeZone];
    NSDateFormatter* df_local = [[NSDateFormatter alloc] init];
    [df_local setTimeZone:currentTimeZone];
    [df_local setDateFormat:@"yyyy.MM.dd G 'at' HH:mm:ss zzz"];
    
    
    
    NSDate* currentDate = [NSDate date];
    NSDate* startDate = ts_utc;
    NSTimeInterval distanceBetweenDates = [startDate timeIntervalSinceDate:currentDate];
    int seconds = (int)distanceBetweenDates % 60;
    int minutes = (int)(distanceBetweenDates / 60) % 60;
    int hours = distanceBetweenDates / 3600;
    
    
    
    //NSLog(@"seconds: %@", seconds);
    if (seconds<0){
        
        NSString *CurrentID=[videoContent objectAtIndex:senderButton.tag];
        NSURL *connection_url = [NSURL URLWithString:CurrentID];
        
        
        connection_url = [NSURL URLWithString:[NSString stringWithFormat:@"http://api.dvidshub.net/hls/live/%@.m3u8?api_key=key-53ce7dc88f935",CurrentID]];
        
        NSLog(@"The id is: %@", CurrentID);
        
        NSLog(@"The url is: %@", connection_url);
        
        
        AVPlayer *player1 = [AVPlayer playerWithURL:connection_url];
        
        // create a player view controller
        AVPlayerViewController *controller = [[AVPlayerViewController alloc]init];
        controller.player = player1;
        
        
        [self presentViewController:controller animated:YES completion:nil];
        [player1 play];
        
        
        NSLog(@"it is time: " );
        
        
    }else {
        
        NSLog(@"Not time yet: " );
    }
    
    
    
}
@end

