//
//  RecentLiveItems.h
//  RecentLiveEvents
//
//  Created by Yahya  on 9/24/17.
//  Copyright © 2017 Towson University. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface RecentLiveItems : NSObject

@property (nonatomic, copy)NSString *myTitle;
@property (nonatomic, copy)NSString *Thumbnail;
@property (nonatomic, copy)NSString *Describe;
@property (nonatomic, copy)NSString *startTime;
@property (nonatomic, copy)NSString *endTime;
@property (nonatomic, copy)NSString *nowTime;
@property (nonatomic, copy)NSString *SrcMp4;



@property (nonatomic, retain) NSData *imageData;


-(void)loadData;

@end
