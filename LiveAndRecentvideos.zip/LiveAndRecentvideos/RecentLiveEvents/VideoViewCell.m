//
//  VideoViewCell.m
//  RecentLiveEvents
//
//  Created by Yahya  on 9/24/17.
//  Copyright © 2017 Towson University. All rights reserved.
//

#import "VideoViewCell.h"
#import "RecentEventViewController.h"


@implementation VideoViewCell
@synthesize imageView1, title, myDescription, myDate, IDs;


-(void)setDetails:(RecentLiveItems *) new
{
    title.text = new.myTitle;
    myDescription.text = new.Describe;
    
    // myDescription.text = new.Describe;
    
    // Vinod : How to print log
    // Comment : veribale name not proper, Give it proper and with meaning, E.g mytile is not proper name, It should be videoTitle.
    NSLog(@" Video Title= %@", new.myTitle);
    
    if(new.imageData)
    {
        UIImage *image = [UIImage imageWithData:new.imageData];
        
        imageView1.image = image;
        
        
    }
    
    else
    {
        [new loadData];
        UIImage *image = [UIImage imageWithData:new.imageData];
        
        imageView1.image = image;
    }
    
    
    
}
@end
