//
//  liveVideoViewCell.m
//  RecentLiveEvents
//
//  Created by Yahya  on 9/24/17.
//  Copyright © 2017 Towson University. All rights reserved.
//

#import "liveVideoViewCell.h"



@implementation liveVideoViewCell

@synthesize startT, endT, title, imageView1, descriptions,remianingTimeLive;


- (void)awakeFromNib {
    [super awakeFromNib];
    // Initialization code
}

- (void)setSelected:(BOOL)selected animated:(BOOL)animated {
    [super setSelected:selected animated:animated];
    
    // Configure the view for the selected state
}

-(void)setDetails:(RecentLiveItems *) new
{
    title.text = new.myTitle;
    
    descriptions.text = new.Describe;

    
    startT.text = [self formatteDate:new.startTime];//new.startTime;
    endT.text = [self formatteDate:new.endTime];//new.endTime;
    
    
    
    //RecentLiveItems *objectLiveVideo = [liveVideoArray objectAtIndex:indexPath.row];
    
    
    NSString *beginDate = new.startTime;
    
    NSDateFormatter *dateFormatter = [[NSDateFormatter alloc] init];
    [dateFormatter setDateFormat:@"yyyy-MM-dd'T'HH:mm:ssZ"]; // 2016-10-04T16:25:00+00:00
    NSDate *ts_utc = [dateFormatter dateFromString:beginDate];
    
    NSTimeZone *currentTimeZone = [NSTimeZone localTimeZone];
    NSDateFormatter* df_local = [[NSDateFormatter alloc] init];
    [df_local setTimeZone:currentTimeZone];
    [df_local setDateFormat:@"yyyy.MM.dd G 'at' HH:mm:ss zzz"];
    
    
    
    NSDate* currentDate = [NSDate date];
    NSDate* startDate = ts_utc;
    NSTimeInterval distanceBetweenDates = [startDate timeIntervalSinceDate:currentDate];
    int seconds = (int)distanceBetweenDates % 60;
    int minutes = (int)(distanceBetweenDates / 60) % 60;
    int hours = distanceBetweenDates / 3600;
    
//    if (seconds<0){
//
//        //remianingTimeLive.hidden=true;
//        remianingTimeLive.text = [NSString stringWithFormat:@"Live now"];
//
//    }else {
//
//    remianingTimeLive.text = [NSString stringWithFormat:@"%2d hrs:%02d min:%02d sec",hours ,minutes, seconds];
//
//    }
    
    
    if(new.imageData)
    {
        UIImage *image = [UIImage imageWithData:new.imageData];
        
        imageView1.image = image;
        
    }
    
    else
    {
        [new loadData];
        UIImage *image = [UIImage imageWithData:new.imageData];
        
        imageView1.image = image;
    }
    
    
    
    
    
}





// This Methode is used to return
- (NSString*)formatteDate:(NSString*)date{
    NSDateFormatter *dateFormatter = [[NSDateFormatter alloc] init];
    [dateFormatter setDateFormat:@"yyyy-MM-dd'T'HH:mm:ssZ"]; // 2016-10-04T16:25:00+00:00
    NSDate *ts_utc = [dateFormatter dateFromString:date];
    NSDateFormatter* df_utc = [[NSDateFormatter alloc] init];
    [df_utc setTimeZone:[NSTimeZone timeZoneWithName:@"UTC"]];
    [df_utc setDateFormat:@"yyyy.MM.dd G 'at' HH:mm:ss zzz"];
    
    NSTimeZone *currentTimeZone = [NSTimeZone localTimeZone];
    NSDateFormatter* df_local = [[NSDateFormatter alloc] init];
    [df_local setTimeZone:currentTimeZone];
    [df_local setDateFormat:@"yyyy.MM.dd  'at' hh:mm:ss a"];
    
    //NSString* ts_utc_string = [df_utc stringFromDate:ts_utc];
    NSString* ts_local_string = [df_local stringFromDate:ts_utc];
    return  ts_local_string;
}

@end
