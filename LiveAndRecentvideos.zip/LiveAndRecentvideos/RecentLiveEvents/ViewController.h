//
//  ViewController.h
//  RecentLiveEvents
//
//  Created by Yahya  on 9/24/17.
//  Copyright © 2017 Towson University. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ViewController :UIViewController<UITableViewDataSource, UITableViewDelegate, NSURLConnectionDataDelegate>
@property (strong, nonatomic) IBOutlet UITableView *myTableView;
- (IBAction)getTop10Button:(id)sender;


@end

